package es.unican.ps.seguros.domain;

public class DatoNoValidoException extends Exception {

}
